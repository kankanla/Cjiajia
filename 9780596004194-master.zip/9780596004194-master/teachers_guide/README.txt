You can find teaching materials for the book here -

http://www.oualline.com/teach